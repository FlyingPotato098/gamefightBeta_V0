extends Player1
